/*********************************************************************
 *
 * Software License Agreement
 *
 *  Copyright (c) 2018,
 *  TU Dortmund - Institute of Control Theory and Systems Engineering.
 *  All rights reserved.
 *
 *  This software is currently not released.
 *  Redistribution and use in source and binary forms,
 *  with or without modification, are prohibited.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Authors: Maximilian Krämer
 *********************************************************************/

#include <robot_utilities/robot_setpoint_manager/objectives/euclidean_setpoint_objective.h>
#include <robot_utilities/robot_setpoint_manager/objectives/length_setpoint_objective.h>
#include <robot_utilities/robot_setpoint_manager/robot_setpoint_manager.h>
#include <ur_utilities/ur_collision/ur_collision.h>
#include <iostream>

using URCollision          = robot_utilities::robot_collision::URCollision;
using RobotSetpointManager = robot_utilities::robot_set_point_manager::RobotSetPointManager;
using LengthObjective      = robot_utilities::robot_set_point_manager::objectives::LengthSetpointObjective;
using RefObjective         = robot_utilities::robot_set_point_manager::objectives::EuclideanSetpointObjective;

int main(int argc, char** argv)
{
    // sleep(5);

    ros::init(argc, argv, "robot_setpoint_manager_test");

    RobotSetpointManager sm(std::make_unique<URCollision>());

    LengthObjective obj1;
    RefObjective obj2(Eigen::Matrix<double, 6, 1>::Zero());

    std::vector<Eigen::VectorXd> result;

    Eigen::Matrix<double, 6, 1> js;
    js << 0.1, 0.2, 0.3, 0.4, 0.5, 0.6;

    sm.setJointSpaceWaypoints({js.transpose()}, {0});
    sm.validate();
    sm.getOptimalWaypoints(obj2, result);

    for (const auto& v : result) std::cout << v << std::endl;

    Eigen::Matrix<double, 6, 1> js1, js2, js3;
    js1 << 0, 0, 0, 0, 0, 0;
    js2 << 0, -0.1, 0, 0.1, 0, 0.1;
    js3 << 0, -0.2, 0, 0.2, 0, 0.2;

    sm.setJointSpaceWaypoints({js1.transpose(), js2.transpose(), js3.transpose()}, {0.0, 0.5, 1.0});
    sm.validate();
    sm.getOptimalWaypoints(obj2, result);
    for (const auto& v : result) std::cout << v << std::endl;

    Eigen::MatrixXd s = Eigen::MatrixXd::Zero(3, 6);
    s.row(0)          = js1.transpose();
    s.row(1)          = js2.transpose();
    s.row(2)          = js3.transpose();

    sm.setJointSpaceWaypoints({s}, {0.0});
    sm.validate();
    sm.getOptimalWaypoints(obj2, result);
    for (const auto& v : result) std::cout << v << std::endl;

    Eigen::MatrixXd s1, s2, s3;
    s1 = s;
    s2 = s;
    s3 = s;

    s2.row(0) = js2.transpose();
    s2.row(1) = js1.transpose();
    s2.row(2) = js3.transpose();

    s3.row(0) << 5, 0, 0, 0, 0, 0;
    s3.row(1) = js2.transpose();
    s3.row(2) = js1.transpose();

    sm.setJointSpaceWaypoints({s1, s2, s3}, {0.0, 0.5, 1.0});
    sm.validate();
    sm.getOptimalWaypoints(obj2, result);
    for (const auto& v : result) std::cout << v << std::endl;

    return 0;
}
