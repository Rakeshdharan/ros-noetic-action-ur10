/*********************************************************************
 *
 * Software License Agreement
 *
 *  Copyright (c) 2021,
 *  TU Dortmund - Institute of Control Theory and Systems Engineering.
 *  All rights reserved.
 *
 *  This software is currently not released.
 *  Redistribution and use in source and binary forms,
 *  with or without modification, are prohibited.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Authors: Maximilian Krämer
 *********************************************************************/

#include <robot_utilities/robot_trajectory_optimization/robot_quadratic_cost_joint_space.h>
#include <robot_utilities/robot_trajectory_optimization/robot_quadratic_cost_task_space.h>
#include <ros/ros.h>
#include <ur_utilities/ur_kinematic/ur_kinematic.h>
#include <chrono>
#include <random>

using URKinematic                  = robot_utilities::robot_kinematic::URKinematic;
using RobotQuadraticCostTaskSpace  = robot_utilities::robot_trajectory_optimization::RobotQuadraticCostTaskSpace;
using RobotQuadraticCostJointSpace = robot_utilities::robot_trajectory_optimization::RobotQuadraticCostJointSpace;

void performTestTS(int iterations, RobotQuadraticCostTaskSpace& cost_function)
{
    Eigen::VectorXd q(6);
    Eigen::VectorXd ref(7);
    Eigen::DiagonalMatrix<double, 3> P, O;
    double c = 0;

    P.setIdentity();
    O.setIdentity();

    cost_function.setP(P);
    cost_function.setO(O);

    ref.head<3>() << -0.5, 0.5, 0.8;
    ref.tail<4>() << 0.0, 0.0, 1.0, 0.0;

    std::chrono::steady_clock::time_point begin, end;
    ulong ns = 0;

    std::uniform_real_distribution<double> random(-2 * M_PI, 2 * M_PI);
    std::default_random_engine re;

    for (int i = 0; i < iterations; ++i)
    {
        q(0) = random(re);
        q(1) = random(re);
        q(2) = random(re);
        q(3) = random(re);
        q(4) = random(re);
        q(5) = random(re);

        begin = std::chrono::steady_clock::now();
        c     = cost_function.computeStateCost(q, ref, ref);
        end   = std::chrono::steady_clock::now();
        ns += std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count();
    }

    std::cout << c << std::endl;

    std::cout << ns / iterations << " ns." << std::endl;
    std::cout << "------------------------------------------------" << std::endl;
}

void performTestJS(int iterations, RobotQuadraticCostJointSpace& cost_function)
{
    Eigen::VectorXd q(6);
    Eigen::VectorXd ref(6);
    Eigen::DiagonalMatrix<double, 6> Q;
    double c = 0;

    Q.setIdentity();
    cost_function.setQ(Q);

    ref << 2.0, 0.0, 0.0, 0.0, 0.0, 0.0;

    std::chrono::steady_clock::time_point begin, end;
    ulong ns = 0;

    std::uniform_real_distribution<double> random(-2 * M_PI, 2 * M_PI);
    std::default_random_engine re;

    for (int i = 0; i < iterations; ++i)
    {
        q(0) = random(re);
        q(1) = random(re);
        q(2) = random(re);
        q(3) = random(re);
        q(4) = random(re);
        q(5) = random(re);

        begin = std::chrono::steady_clock::now();
        c     = cost_function.computeStateCost(q, ref, ref);
        end   = std::chrono::steady_clock::now();
        ns += std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count();
    }
    std::cout << c << std::endl;

    std::cout << ns / iterations << " ns." << std::endl;
    std::cout << "------------------------------------------------" << std::endl;
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "ur_trajectory_optimization_test");
    ros::NodeHandle n("~");

    RobotQuadraticCostTaskSpace ts;
    RobotQuadraticCostJointSpace js;

    ts.initialize(nullptr, std::make_unique<URKinematic>());
    js.initialize(nullptr, std::make_unique<URKinematic>());

    int iterations = 100000;

    std::cout << "------------------------------------------------" << std::endl;
    std::cout << "Benchmarking RobotQuadraticCostTaskSpace using " << iterations << " samples:" << std::endl;
    performTestTS(iterations, ts);

    std::cout << "------------------------------------------------" << std::endl;
    std::cout << "Benchmarking RobotQuadraticCostJointSpace using " << iterations << " samples:" << std::endl;
    performTestJS(iterations, js);

    return 0;
}
