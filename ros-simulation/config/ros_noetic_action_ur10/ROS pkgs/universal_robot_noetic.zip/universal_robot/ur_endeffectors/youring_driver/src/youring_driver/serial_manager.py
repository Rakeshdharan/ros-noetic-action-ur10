#!/usr/bin/python

import serial
import binascii
import time
from struct import *
import config as cfg

# ----------------------------------------------------------------------------------------------------------------------------------
class youring_serial_manager():
    # --------------------------------------------------------------------------------------
    def __init__(self, baudrate, poly, port_list, timeout, led_number):
        self.uring_founded = False;

        self.poly = poly  # poly = 0x1021

        #print("youring_serial_manager() -> timeout set :: ", timeout)
        for i in range(len(port_list)):
            #print("Testing port: ", port_list[i])
            self.ser = serial.Serial()
            self.ser.port = port_list[i]  # "/dev/ttyUSBx"
            self.ser.baudrate = baudrate  # baudrate
            self.ser.bytesize = serial.EIGHTBITS  # number of bits per bytes
            self.ser.parity = serial.PARITY_NONE  # set parity check: no parity
            self.ser.stopbits = serial.STOPBITS_ONE  # number of stop bits
            self.ser.timeout = timeout  # block read - timeout
            #self.ser.write_timeout = 0             # write - timeout
            self.ser.xonxoff = False  # disable sofser.flushInput()

            self.ser.open()

            leds = []
            for k in range(led_number): leds.append([0, 0, 0])
            answ = self.write_message(leds, [0, 0], 0x02)
            #print("answ -> ", answ)
            if answ == cfg.OK:
                status = self.read_answer_normal(True)
                #print("status -> ", status)
                # status, board_status, bt_0, bt_1, server_id, cl_sig_lev, srv_sig_lev = self.read_answer_normal(True);
                if status[0] == 0:
                    self.uring_founded = True
                    print "Connection stablished with port: ", port_list[i]
                    break;
                else:
                    self.ser.close()

    # --------------------------------------------------------------------------------------
    def check_CRC(self, message):
        # link per controllo del calcolo della checsum
        # http://www.sunshine2k.de/coding/javascript/crc/crc_js.html
        start_value = 0x0000;
        message += '\x00\x00'
        for byte in message:
            mask = 0x80
            while (mask > 0):
                start_value <<= 1
                if ord(byte) & mask: start_value += 1
                mask >>= 1
                if start_value > 0xffff:
                    start_value &= 0xffff;
                    start_value ^= self.poly
        return start_value

    # --------------------------------------------------------------------------------------
    def padded_hex(self, i, j):
        given_int = i;
        given_len = j
        hex_result = hex(given_int)[2:];
        num_hex_chars = len(hex_result);
        extra_zeros = '0' * (given_len - num_hex_chars)
        return (
            hex_result if num_hex_chars == given_len else '?' * given_len if num_hex_chars > given_len else extra_zeros + hex_result if num_hex_chars < given_len else None)

    # --------------------------------------------------------------------------------------
    def little_endian_16bit(self, string):
        e = string;
        first = e[0] + e[1];
        second = e[2] + e[3];
        return binascii.unhexlify(second + first)


    ################################## RECEVING METHODDS ################################
    def my_read(self, byte_to_read):
        byte = self.ser.read(byte_to_read)
        # print "### my_read ###", ":".join("{:02x}".format(ord(c)) for c in byte) , byte_to_read
        return byte

    # --------------------------------------------------------------------------------------
    def read_answer_normal(self, finding_uring_flag):
        t_read = time.time()
        start_bytes_counter = 0;
        attempt_counter = 0
        #print "[ READING ANSWER ] "
        while True:
            try:
                #self.ser.flush()
                g = self.ser.read(1)
                #self.ser.flush()
                #self.print_hex_message(g)
                if g == cfg.START_BYTE:
                    start_bytes_counter += 1
                    attempt_counter = 0
                else:
                    if finding_uring_flag:
                        return -1, -1, -1, -1, -1, -1, -1, -1, -1
                    #print("wait to read board answer message ... ")
                    start_bytes_counter = 0
                if start_bytes_counter >= 4:
                    # self.ser.flush();  gg = self.ser.read(1);  board_status = unpack('B', gg)
                    gg = self.my_read(1);
                    board_status = unpack('B', gg)

                    if board_status[0] < 0 or board_status[0] > 3:
                        print("board state value IS NOT VALID")
                    # print "board status is ", board_status[0]

                    client_sw_version = unpack('B', self.my_read(1))
                    server_sw_version = unpack('B', self.my_read(1))
                    # print "status :: " , board_status[0]
                    # self.ser.flush();  button_state_raw = self.ser.read(2); button_state = unpack('BB', button_state_raw)
                    button_state_raw = self.my_read(2);
                    button_state = unpack('BB', button_state_raw)
                    # print "button state :: " , button_state[0] , " - " , button_state[1]
                    buttons_not_valid = False;
                    if button_state[0] != 0 and button_state[0] != 1:
                        buttons_not_valid = True;
                        print("button_0 state = ", button_state[0], " value IS NOT VALID")

                    if button_state[1] != 0 and button_state[1] != 1:
                        buttons_not_valid = True;
                        print("button_1 state = ", button_state[1], " value IS NOT VALID")
                    # print "button[0] is ", button_state[0]
                    # print "button[1] is ", button_state[1]

                    # read server id
                    # self.ser.flush();  server_id_raw = self.ser.read(6); server_id = unpack('BBBBBB', server_id_raw)
                    server_id_raw = self.my_read(6);
                    server_id = unpack('BBBBBB', server_id_raw)
                    # print "server_id[0] is ", server_id[0]
                    # print "server_id[1] is ", server_id[1]
                    # print "server_id[2] is ", server_id[2]
                    # print "server_id[3] is ", server_id[3]
                    # print "server_id[4] is ", server_id[4]
                    # print "server_id[5] is ", server_id[5]

                    # read client side signal level
                    # self.ser.flush();  client_sig_lev_raw = self.ser.read(2); client_sig_lev = unpack('BB', client_sig_lev_raw)
                    client_sig_lev_raw = self.my_read(2);
                    client_sig_lev = unpack('BB', client_sig_lev_raw)
                    # print "client_sig_lev[0] is ", client_sig_lev[0]
                    # print "client_sig_lev[1] is ", client_sig_lev[1]

                    # read server side signal level
                    # self.ser.flush();  server_sig_lev_raw = self.ser.read(2); server_sig_lev = unpack('BB', server_sig_lev_raw)
                    server_sig_lev_raw = self.my_read(2);
                    server_sig_lev = unpack('BB', server_sig_lev_raw)
                    # print "server_sig_lev[0] is ", server_sig_lev[0]
                    # print "server_sig_lev[1] is ", server_sig_lev[1]

                    # read server side lost packages
                    # self.ser.flush();  lost_pkgs_raw = self.ser.read(2); lost_pkgs = unpack('BB', lost_pkgs_raw)
                    lost_pkgs_raw = self.my_read(2);
                    lost_pkgs = unpack('BB', lost_pkgs_raw)
                    # print "lost_pkgs[0] is ", lost_pkgs[0]
                    # print "lost_pkgs[1] is ", lost_pkgs[1]

                    # read corrupted packages
                    # self.ser.flush();  corrupted_pkgs_raw = self.ser.read(2); corrupted_pkgs = unpack('BB', corrupted_pkgs_raw)
                    corrupted_pkgs_raw = self.my_read(2);
                    corrupted_pkgs = unpack('BB', corrupted_pkgs_raw)
                    # print "corrupted_pkgs[0] is ", corrupted_pkgs[0]
                    # print "corrupted_pkgs[1] is ", corrupted_pkgs[1]

                    # self.ser.flush();  crc_raw = self.ser.read(2); crc = unpack('2B', crc_raw); self.ser.flush()
                    crc_raw = self.my_read(2);
                    crc = unpack('2B', crc_raw);
                    # message = cfg.MESSAGE_HEADER  + pack('3B', board_status[0], button_state[0], button_state[1] ) + crc_raw
                    crc_computed = self.check_CRC(
                        cfg.MESSAGE_HEADER + pack('19B', board_status[0], client_sw_version[0], server_sw_version[0],
                                                  button_state[0], button_state[1],
                                                  server_id[0], server_id[1], server_id[2], server_id[3], server_id[4],
                                                  server_id[5],
                                                  client_sig_lev[0], client_sig_lev[1],
                                                  server_sig_lev[0], server_sig_lev[1],
                                                  lost_pkgs[0], lost_pkgs[1],
                                                  corrupted_pkgs[0], corrupted_pkgs[1]))

                    if self.little_endian_16bit(self.padded_hex(crc_computed, 4)) != crc_raw:
                        print("wrong crc")
                        if buttons_not_valid: button_state[0] = 0; button_state[1] = 0;
                        return 3, board_status, button_state[0], button_state[1], server_id, unpack('H',
                                                                                                    client_sig_lev_raw), unpack(
                            'H', server_sig_lev_raw), client_sw_version, server_sw_version
                    else:
                        if buttons_not_valid: button_state[0] = 0; button_state[1] = 0;
                        return 0, board_status, button_state[0], button_state[1], server_id, unpack('H',
                                                                                                    client_sig_lev_raw), unpack(
                            'H', server_sig_lev_raw), client_sw_version, server_sw_version
            except Exception as e:
                print("read_answer_normal exception -> " + str(e))
                time.sleep(1)

            # if str(e) == '(5, \'Input/output error\')':
            # return -6, message_size, button_state[0] , button_state[1], server_id, unpack('H', client_sig_lev_raw), unpack('H', server_sig_lev_raw)
            # else:
            # return -5, message_size, button_state[0] , button_state[1], server_id, unpack('H', client_sig_lev_raw), unpack('H', server_sig_lev_raw)


    # --------------------------------------------------------------------------------------
    ################################## SENDING METHODDS ##################################
    # --------------------------------------------------------------------------------------
    def write_message(self, leds, buzzer_status, cmd_byte):
        #print "[ CMD SENDING ]  --- led manager  --- "
        # starting part of the message
        message = cfg.MESSAGE_HEADER

        # command byte 0xFF: Standard packet - 0x01: Client unpair request, init new scan - 0x02: Board status request (No BLE Data)
        message += pack('B', cmd_byte)

        # buzzer status
        message += pack('<H', buzzer_status[cfg.BZ_FREQUENCY_INDEX]);
        message += pack('B', buzzer_status[cfg.BZ_DC_INDEX])
        #self.print_hex_message(message)

        # leds management
        for led in leds: message += pack('3B', led[cfg.R_INDEX], led[cfg.G_INDEX], led[cfg.B_INDEX])
        crc = self.padded_hex(self.check_CRC(message), 4);
        message += self.little_endian_16bit(crc);
        #self.print_hex_message(message)
        try:
            self.ser.flush()
            self.ser.write(message)
            self.ser.flush()
        except Exception as e:
            print("write_message exception -> " + str(e))
            time.sleep(1)
            return 0
        return cfg.OK


    # --------------------------------------------------------------------------------------
    def print_hex_message(self, message):
        ms_p = binascii.hexlify(message)
        print "message :: ",
        for k in range(0, len(ms_p), 2): print "0x" + ms_p[k:k + 2],
        print
# --------------------------------------------------------------------------------------
