#!/usr/bin/env python3

import rospy
import math

FLAG_DEBUG = False

if FLAG_DEBUG:
    XML_CONFIG_PATH = "/home/velasco/daemon/uring_daemon_cfg.xml"
    SCRIPT_PATH = "/home/velasco/daemon/uring_custom_button_script.script"
else:
    XML_CONFIG_PATH = "/home/velasco/daemon/uring_daemon_cfg.xml"
    SCRIPT_PATH = "/home/velasco/daemon/uring_custom_button_script.script"
CLEAR_RTDE_PATH = "reset_rtde.script"

# general
OK = 1
LED_NUMBER = 30

# serial manager
BAUDRATE = 115200
POLY = 0x1021
TIMEOUT = 0.5
START_BYTE = '\xff'
R_INDEX = 0
G_INDEX = 1
B_INDEX = 2
BZ_FREQUENCY_INDEX = 0
BZ_DC_INDEX = 1
MESSAGE_HEADER = '\xff\xff\xff\xff'

# led management
CYCLE_TIME = 0.01
CYCLE_PERIOD = 0.04

# BUZZER_MIN_PITCH = 200
#BUZZER_MIN_PITCH = 4000
BUZZER_MIN_PITCH = 1000
BUZZER_MAX_PITCH = 5000
BUZZER_MIN_DC = 25
BUZZER_MAX_DC = 50

BUTTONS_TIME_FILTER = 0.06

REVERSE_ID_LIST = [
"220.204.57.159.253.144" ,# 77
"216.204.57.159.253.144" ,# 79
"146.220.57.159.253.144" ,# 81
"94.226.57.159.253.144"  ,# 82
"28.206.57.159.253.144"  ,# 83
"169.102.84.87.11.0"     ,# 84
"80.217.119.87.11.0"     ,# 85
"105.244.85.87.11.0"     ,# 86
"34.205.57.159.253.144"  ,# 88
"195.102.84.87.11.0"     ,# 90
"87.244.85.87.11.0"      ,# 92
"36.106.84.87.11.0"      ,# 93
"103.226.57.159.253.144" ,# 94
"135.215.119.87.11.0"    ,# 95
"248.236.119.87.11.0"    ,# 97
"177.102.84.87.11.0"     ,# 100
"27.206.57.159.253.144"  ,# 101
"206.102.84.87.11.0"     ,# 102
"134.244.85.87.11.0"     ,# 103
"105.239.119.87.11.0"    ,# 104
"55.238.119.87.11.0"     ,# 105
"182.102.84.87.11.0"     ,# 106
"78.86.91.87.11.0"       ,# 107
"95.244.85.87.11.0"      ,# 108
"249.239.119.87.11.0"     # 109
]



