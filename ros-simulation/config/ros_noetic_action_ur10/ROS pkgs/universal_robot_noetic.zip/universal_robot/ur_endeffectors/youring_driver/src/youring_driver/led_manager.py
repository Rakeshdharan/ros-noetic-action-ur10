#!/usr/bin/python

import threading
import time
import os
from threading import Thread
import sys
from youring_driver.msg import LEDCommand as led_command
from youring_driver.msg import BuzzerCommand as buzzer_command
import config as cfg
from serial_manager import youring_serial_manager


# --------------------------------------------------------------------------------------------------
class youring_led_manager(threading.Thread):
    # --------------------------------------------------------------------------------------------------
    def __init__(self, port):
        threading.Thread.__init__(self)

        self.__check_reverse_button_completed = False
        self.__buttons_are_reversed = False
        self.uring_found = False

        while not self.uring_found:
            try:
                self.serial_mngr = youring_serial_manager(cfg.BAUDRATE, cfg.POLY, [port], cfg.TIMEOUT, cfg.LED_NUMBER)
                self.uring_found = self.serial_mngr.uring_founded
                break;
            except:
                print "Connection was not possible with port: ", port
                print "Will attemp to connect to any available /dev/ttyUSB* port"
                f = os.popen('ls /dev/ttyUSB*')
                try:
                    self.serial_mngr = youring_serial_manager(cfg.BAUDRATE, cfg.POLY, f.read().split(), cfg.TIMEOUT, cfg.LED_NUMBER)
                    self.uring_found = self.serial_mngr.uring_founded
                except:
                    pass

            if not self.uring_found:
                resp = raw_input("Not connected! Check connection or permissions. Press enter to retry")
                time.sleep(0.2)

        self.__lock_buttons = threading.Lock()
        self.lock_bluetooth = threading.Lock()
        self.lock_unpair_request = threading.Lock()

        #Led color parameters
        self.__leds = []
        for k in range(cfg.LED_NUMBER):
            self.__leds.append([0, 0, 0])

        #Buzzer related parameters
        self.__buzzer_pitch = 0
        self.__buzzer_dc = 0

        self.__unpair_request = False

        self.usb_key_disconnected = False

        # Serial connection parameters
        self.__board_status = 3
        self.__server_id = [0, 0, 0, 0, 0, 0]
        self.__client_signal_level = 0
        self.__server_signal_level = 0
        self.__client_sw_version = 0
        self.__server_sw_version = 0
        self.__button_0_status = 0
        self.__button_1_status = 0
        self.__profile_list = []

        # Button related parameters
        self.__prev_bt_sent_0, self.__prev_bt_sent_1 = 0, 0
        self.__prev_bt_read_0, self.__prev_bt_read_1 = 0, 0
        self.__bt0_cnt, self.__bt1_cnt = 0, 0
        self.__bt_0, self.__bt_1 = 0, 0

        self.__t_b = time.time()
        self.start_message_thread()

        self.start()
        print("[ LED MANAGER  ] ---  initialized")

    # --------------------------------------------------------------------------------------------------

    def run(self):
        self.__read_write_message()

    # --------------------------------------------------------------------------------------------------
    def get_buttons_status(self):
        bt_0_to_send, bt_1_to_send = 0, 0

        self.__lock_buttons.acquire()
        bt_0_read, bt_1_read = self.__bt_0, self.__bt_1
        self.__lock_buttons.release()

        # time filter
        if bt_0_read == self.__prev_bt_read_0:
            self.__bt0_cnt = self.__bt0_cnt + cfg.CYCLE_TIME
        else:
            self.__bt0_cnt = 0
        if self.__bt0_cnt >= cfg.BUTTONS_TIME_FILTER:
            bt_0_to_send = bt_0_read
        else:
            bt_0_to_send = self.__prev_bt_sent_0
        self.__prev_bt_read_0 = bt_0_read

        if bt_1_read == self.__prev_bt_read_1:
            self.__bt1_cnt = self.__bt1_cnt + cfg.CYCLE_TIME
        else:
            self.__bt1_cnt = 0
        if self.__bt1_cnt >= cfg.BUTTONS_TIME_FILTER:
            bt_1_to_send = bt_1_read
        else:
            bt_1_to_send = self.__prev_bt_sent_1
        self.__prev_bt_read_1 = bt_1_read

        self.__prev_bt_sent_0, self.__prev_bt_sent_1 = bt_0_to_send, bt_1_to_send
        return bt_0_to_send, bt_1_to_send

    # --------------------------------------------------------------------------------------------------
    def get_bluetooth_infos(self):
        # print "### led_manager ### get_bluetooth_infos()"
        self.lock_bluetooth.acquire()
        board_status = self.__board_status
        server_id = self.__server_id
        # cl_sig_lev = self.__client_signal_level
        # srv_sig_lev = self.__server_signal_level
        cl_sig_lev = int(self.__client_signal_level[0])
        srv_sig_lev = int(self.__server_signal_level[0])
        cl_sw_vrs = int(self.__client_sw_version[0])
        srv_sw_vrs = int(self.__server_sw_version[0])
        self.lock_bluetooth.release()

        # return board_status, server_id, cl_sig_lev, srv_sig_lev
        # return board_status, server_id, 0, 1
        return board_status, server_id[0], server_id[1], server_id[2], server_id[3], server_id[4], server_id[
            5], cl_sig_lev, srv_sig_lev, cl_sw_vrs, srv_sw_vrs


    # --------------------------------------------------------------------------------------------------
    def __send_message(self):

        self.__t_b = time.time()

        cmd = 255
        buzzer_pitch = self.__buzzer_pitch
        buzzer_dc = self.__buzzer_dc
        leds=self.__leds

        self.lock_bluetooth.acquire()
        if self.__board_status != 0:
            cmd = 2
            buzzer_pitch = 0
            buzzer_dc = 0
            for led in leds:
                led = [0, 0, 0]
        self.lock_bluetooth.release()

        self.lock_unpair_request.acquire()
        if self.__unpair_request == True:
            cmd = 1
            buzzer_pitch = 0
            buzzer_dc = 0
            for led in leds:
                led = [0, 0, 0]
            self.__unpair_request = False
        self.lock_unpair_request.release()

        #print('BOARD STATUS ', self.__board_status)
        #print("CMD IS ", cmd)
        #print("pitch & dc", self.__buzzer_pitch, self.__buzzer_dc)

        answ = self.serial_mngr.write_message(self.__leds, [buzzer_pitch, buzzer_dc], cmd)
        if answ == cfg.OK:
            return True
        else:
            return False

    # --------------------------------------------------------------------------------------------------
    def __read_write_message(self):
        while True:
            status, board_status, bt_0, bt_1, server_id, cl_sig_lev, srv_sig_lev, cl_sw_version, srv_sw_version = self.serial_mngr.read_answer_normal(True)

            if status == -6:
                self.usb_key_disconnected = True

            self.lock_bluetooth.acquire()
            self.__board_status = board_status[0]
            self.__server_id = server_id
            self.__client_signal_level = cl_sig_lev
            self.__server_signal_level = srv_sig_lev
            self.__client_sw_version = cl_sw_version
            self.__server_sw_version = srv_sw_version
            self.lock_bluetooth.release()

            if not self.__check_reverse_button_completed:
                mac_address = str(server_id[0])+"."+str(server_id[1])+"."+str(server_id[2])+"."+str(server_id[3])+"."+str(server_id[4])+"."+str(server_id[5])
                #print("going to check reverse button for " + mac_address)
                for yr_id in cfg.REVERSE_ID_LIST:
                    if mac_address == yr_id:
                        print("buttons are reversed")
                        self.__buttons_are_reversed = True
                        break
                self.__check_reverse_button_completed = True

            self.__lock_buttons.acquire()
            if self.__buttons_are_reversed:
                self.__bt_0 = bt_1
                self.__bt_1 = bt_0
            else:
                self.__bt_0 = bt_0
                self.__bt_1 = bt_1
            self.__lock_buttons.release()

            self.__profile_list.append(time.time() - self.__t_b)


    # --------------------------------------------------------------------------------------------------
    def set_unpair_request(self):
        self.lock_unpair_request.acquire()
        self.__unpair_request = True
        self.lock_unpair_request.release()

    # --------------------------------------------------------------------------------------------------
    def start_message_thread(self):
        try:
            t = threading.Timer(cfg.CYCLE_PERIOD, self.start_message_thread);
            t.start()
            if not self.__send_message():
                print("send message exception, killing application, cancel thread")
                sys.stdout.flush()
                t.cancel()
                os._exit(0)
        except Exception as e:
            print(e)


    # --------------------------------------------------------------------------------------------------
    def set_led_param(self, led_msg):
    #TODO: Check if ids are between 0 and 29, and colors between 0 to 255. Also dimensions should match (and should not be bigger than 1x30)
        for led in self.__leds:
            led = [0, 0, 0]

        for i in range(len(self.__leds)):
            self.__leds[i] = [0, 0, 0]

        for k in range(len(led_msg.led_id)):
            self.__leds[ord(led_msg.led_id[k])] = [ord(led_msg.color_Red[k]), ord(led_msg.color_Green[k]), ord(led_msg.color_Blue[k])]

    # --------------------------------------------------------------------------------------------------


    # --------------------------------------------------------------------------------------------------
    def set_buzzer_param(self, buzzer_msg):
        if buzzer_msg.active_flag:
            #TODO: Check if pitch and dc are between 0 and 100
            self.__buzzer_pitch = cfg.BUZZER_MIN_PITCH + (cfg.BUZZER_MAX_PITCH - cfg.BUZZER_MIN_PITCH)*buzzer_msg.pitch/100
            self.__buzzer_dc = cfg.BUZZER_MIN_DC + (cfg.BUZZER_MAX_DC - cfg.BUZZER_MIN_DC)*buzzer_msg.dc/100
        else:
            self.__buzzer_pitch = 0.
            self.__buzzer_dc = 0.


    # --------------------------------------------------------------------------------------------------
