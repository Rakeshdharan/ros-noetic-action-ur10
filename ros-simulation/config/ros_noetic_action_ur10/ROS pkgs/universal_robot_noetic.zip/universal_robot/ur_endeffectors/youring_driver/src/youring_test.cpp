/*********************************************************************
 *
 * Software License Agreement
 *
 *  Copyright (c) 2021,
 *  TU Dortmund - Institute of Control Theory and Systems Engineering.
 *  All rights reserved.
 *
 *  This software is currently not released.
 *  Redistribution and use in source and binary forms,
 *  with or without modification, are prohibited.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Authors: Rodrigo Velasco, Maximilian Krämer
 *********************************************************************/

#include <math.h>
#include <ros/ros.h>
#include <youring_driver/ButtonStatus.h>
#include <youring_driver/BuzzerCommand.h>
#include <youring_driver/LEDCommand.h>

bool button0 = false;
bool button1 = false;

void button_callback(const youring_driver::ButtonStatus::ConstPtr& msg)
{
    button0 = msg->button0;
    button1 = msg->button1;
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "general_test");
    ros::NodeHandle n;

    // button state subscriber
    ros::Subscriber button_sub = n.subscribe("/youring/button_status", 1, button_callback);

    // led and buzzer command publisher
    ros::Publisher led_pub    = n.advertise<youring_driver::LEDCommand>("/youring/led_command", 1000, true);
    ros::Publisher buzzer_pub = n.advertise<youring_driver::BuzzerCommand>("/youring/buzzer_command", 1000, true);

    // init
    int color_counter  = 0;
    int color          = 0;
    int led_counter    = 0;
    int count          = 0;
    int buzzer_counter = 0;
    int buzz_count     = 0;
    int pitch          = 0;

    // create msgs
    youring_driver::LEDCommand msg;
    youring_driver::BuzzerCommand buzz_msg;

    ros::Rate loop_rate(20);
    while (ros::ok())
    {
        if (button0)
        {
            color_counter = color_counter % 510;
            color         = color_counter;

            msg.led_id.clear();
            msg.color_Red.clear();
            msg.color_Green.clear();
            msg.color_Blue.clear();

            led_counter = led_counter % 30;
            count       = led_counter;

            for (int i = 0; i <= count; ++i)
            {
                msg.led_id.push_back(i);
                msg.color_Red.push_back(0.01581 * (color - 127) * (color - 127));
                msg.color_Green.push_back(color);
                msg.color_Blue.push_back(255 - color);
            }
            led_pub.publish(msg);

            color_counter += 2;

            ++led_counter;
        }
        else
        {
            msg.led_id.clear();
            msg.color_Red.clear();
            msg.color_Green.clear();
            msg.color_Blue.clear();

            led_pub.publish(msg);

            color_counter = 0;
            led_counter   = 0;
        }

        if (button1)
        {
            buzz_msg.active_flag = true;

            buzzer_counter = buzzer_counter % 200;

            if (buzzer_counter > 100)
                pitch = 200 - buzzer_counter;
            else
                pitch = buzzer_counter;

            buzz_msg.pitch = pitch;
            buzz_msg.dc    = 0;

            buzzer_pub.publish(buzz_msg);

            ++buzz_count;

            if (buzz_count > 10)
            {
                buzzer_counter += 10;
                buzz_count = 0;
            }
        }
        else
        {
            buzz_msg.active_flag = false;
            buzz_msg.pitch       = 0;
            buzz_msg.dc          = 0;

            buzzer_pub.publish(buzz_msg);

            buzzer_counter = 0;
            buzz_count     = 0;
        }

        ros::spinOnce();

        loop_rate.sleep();
    }

    return 0;
}
