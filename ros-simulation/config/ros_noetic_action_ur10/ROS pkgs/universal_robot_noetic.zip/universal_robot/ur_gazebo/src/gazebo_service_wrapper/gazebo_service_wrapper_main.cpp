/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2015,
 *  TU Dortmund - Institute of Control Theory and Systems Engineering.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of the institute nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Author: Maximilian Krämer
 *********************************************************************/

#include <gazebo_msgs/ApplyBodyWrench.h>
#include <ros/ros.h>
#include <ur_msgs/ApplyBodyWrench.h>
#include <memory>

std::unique_ptr<ros::ServiceClient> srv_client;

void applyBodyWrenchCallback(const ur_msgs::ApplyBodyWrenchConstPtr msg)
{
    gazebo_msgs::ApplyBodyWrench srv;

    // copy into request
    srv.request.wrench          = msg->wrench;
    srv.request.duration        = msg->duration;
    srv.request.body_name       = msg->body_name;
    srv.request.start_time      = msg->start_time;
    srv.request.reference_frame = msg->reference_frame;
    srv.request.reference_point = msg->reference_point;

    if (!srv_client->call(srv))
    {
        ROS_WARN_STREAM("GazeboServiceWrapper: Failed to call service " << srv_client->getService());
    }
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "gazebo_service_wrapper");
    ros::NodeHandle n("~");

    ROS_INFO("gazebo_service_wrapper started");

    // create service
    srv_client = std::make_unique<ros::ServiceClient>(n.serviceClient<gazebo_msgs::ApplyBodyWrench>("/gazebo/apply_body_wrench"));

    // create subscriber
    ros::Subscriber sub = n.subscribe("apply_body_wrench", 1, &applyBodyWrenchCallback);

    ros::spin();
    return 0;
}
